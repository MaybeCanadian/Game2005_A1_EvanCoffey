#include <glm/gtx/matrix_interpolation.hpp>

int main()
{
	int Error(0);

	return Error;
}


